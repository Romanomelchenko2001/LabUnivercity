﻿namespace Search
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button Transform;
        private System.Windows.Forms.RadioButton LINQ;
        private System.Windows.Forms.RadioButton SAX;
        private System.Windows.Forms.RadioButton DOM;
        private System.Windows.Forms.CheckBox Speciality;
        private System.Windows.Forms.CheckBox Group;
        private System.Windows.Forms.CheckBox Room;
        private System.Windows.Forms.CheckBox Surname;
        private System.Windows.Forms.CheckBox NameCheck;
        private System.Windows.Forms.CheckBox PhoneNumber;
        private System.Windows.Forms.ComboBox SpecialityBox;
        private System.Windows.Forms.ComboBox GroupBox;
        private System.Windows.Forms.ComboBox RoomBox;
        private System.Windows.Forms.ComboBox SurnameBox;
        private System.Windows.Forms.ComboBox NameBox;
        private System.Windows.Forms.ComboBox PhoneBox;
        private System.Windows.Forms.Button transfor;
    }
}

